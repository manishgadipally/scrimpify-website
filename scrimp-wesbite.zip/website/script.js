function reloadElements(){
    gsap.fromTo('.scrimp-main-container-one h1', {duration: 2, x: 0, opacity: 0},{duration: 1, x: 0, opacity: 1 , stagger:0.2})
    gsap.fromTo('.scrimp-main-container-two h1', {duration: 3, x: 0, opacity: 0},{duration: 1, x: 0, opacity: 1,stagger:0.2})
    gsap.fromTo('.scrimp-main-container-three h1', {duration:4, x: 0, opacity: 0},{duration: 1, x: 0, opacity: 1, stagger:0.2})
    gsap.fromTo('.scrimp-footer-container div', {duration: 4, x: 0, opacity: 0}, {duration: 1, x: 0, opacity: 1, stagger:0.1})
}
window.onload = reloadElements;